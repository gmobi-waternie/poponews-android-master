var callbackList = [];
var callbackCounter = 0;

var system ={
	win : false,
	mac : false,
	xll : false
};

var plat = navigator.platform;
system.win = plat.indexOf("Win") == 0;
system.mac = plat.indexOf("Mac") == 0;
system.x11 = (plat == "X11") || (plat.indexOf("Linux") == 0);

function getPlatform(){
	if(system.win||system.mac||system.xll){
		return "PC";
	}else{
		return "MOBILE";
	}	
}

function jsCallNativeApi(action, params, callback){
	var timestamp = Math.round(new Date().getTime()/1000);
	var cItem = {
		'id': timestamp + "_" + callbackCounter,
		'callback': callback,
		'action': action,
		'params': params
	};

	callbackCounter++;
	if (callbackCounter > 99999999)
		callbackCounter = 0;
	
	if (callback != null)
		callbackList.push(cItem);
	
	checkCallbackList();

	var paramsJsonArrayStr = JSON.stringify(params);
	
	if (getPlatform() == "MOBILE"){
		try{
			window._JsToNativePluginApi.exec(cItem.id, cItem.action, paramsJsonArrayStr);
		} catch(e){
			console.log('call android api error!');
		}
	}
}

function callJsCallback(id, status, message){
	console.log("android callback:" + id + ",  " + status  + ",  " + message);
	var count = callbackList.length;
	for (var i = 0; i < count; i++){
		var item = callbackList[i];
		if (id == item.id){
			if (status == "success"){
				if (item.callback){
					item.callback(true, message);
				}
			} else {
				if (item.callback)
					item.callback(false, message);
			}

			callbackList.splice(i, 1);
			break;
		}
	} 

	checkCallbackList();
}

function checkCallbackList(){
	var timestamp = Math.round(new Date().getTime()/1000);
	var count = callbackList.length;
	for (var i = 0; i < count; i++){
		var item = callbackList[i];
		if (item.type != "permanent"){
			var idTimestamp = getCallbackIdTimestamp(item.id);
			if (timestamp - idTimestamp > 1000*60*10){
				callbackList.splice(i, 1);
				count--;
				i--;
			}
		}
	}
}

function arrayToJsonarrayString(p){
	if (p == null)
		return null;

	var pCount = p.length;
	if (pCount <= 0)
		return null;
	var jsonArrayStr = '[';
	var j = 0;
	for (j = 0; j < pCount; j++) {
		var item = p[j];
		
		if (j != 0)
			jsonArrayStr += ',';
		
		if (item == null)
			jsonArrayStr += 'null';
		else{
			var itemStr = null;
			if ($.type(item) == "object")
				itemStr = JSON.stringify(item);
			else
				itemStr = item.toString();
			jsonArrayStr += '\'' + itemStr + '\'';
		}

	};
	jsonArrayStr += ']';
	return jsonArrayStr;
}

function getCallbackIdTimestamp(id){
	if (id == null)
		return 0;
	var pos = id.indexOf("_");
	return id.substr(0, pos);
}